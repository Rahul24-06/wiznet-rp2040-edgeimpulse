#include "nina_pins.h"

NinaPin  LEDR(27);
NinaPin  LEDG(25);
NinaPin  LEDB(26);
NinaPin  A4(34);
NinaPin  A5(39);
NinaPin  A6(36);
NinaPin  A7(35);
