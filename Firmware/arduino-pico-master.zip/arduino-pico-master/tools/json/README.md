This directory contains JSON board definitions for use with Platform.IO
